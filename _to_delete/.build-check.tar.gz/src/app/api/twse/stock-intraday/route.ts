import { NextRequest, NextResponse } from 'next/server';
import { getAdminDb } from '@/lib/firebase-admin';

export const runtime = 'nodejs';

const NO_STORE = { 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' };
const taipeiDate = () => {
  const tw = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Taipei' }));
  return `${tw.getFullYear()}-${String(tw.getMonth() + 1).padStart(2, '0')}-${String(tw.getDate()).padStart(2, '0')}`;
};

// Real-time intraday from the resident daemon's MIS sweep (marketIntraday/latest).
// Independent of Yahoo, which lags ~20min and is often empty at the open.
async function fetchDaemonIntraday(code: string) {
  try {
    const db = getAdminDb();
    if (!db) return null;
    const snap = await db.collection('marketIntraday').doc('latest').get();
    const data = snap.data();
    if (!data || data.date !== taipeiDate()) return null; // only today's series
    const series = JSON.parse(data.seriesJson || '{}');
    const s = series[code];
    if (!s || !Array.isArray(s.pts) || s.pts.length === 0) return null;
    const ticks = s.pts.map((p: [number, number, number]) => {
      const tw = new Date(new Date(p[0] * 1000).toLocaleString('en-US', { timeZone: 'Asia/Taipei' }));
      const timeStr = `${String(tw.getHours()).padStart(2, '0')}:${String(tw.getMinutes()).padStart(2, '0')}`;
      return { time: p[0], timeStr, close: p[1], volume: p[2] ?? 0 };
    });
    return { prevClose: s.prev ?? ticks[0].close, ticks };
  } catch {
    return null;
  }
}

async function fetchIntraday(symbol: string) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1m&range=1d&includePrePost=false`;
  try {
    // 4s 上限：盤中每 5 秒輪詢，避免偶發慢回應拖慢更新(即時尾段仍由 daemon/即時報價補上)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'Accept': 'application/json',
        'Referer': 'https://finance.yahoo.com/',
      },
      cache: 'no-store',
    });

    clearTimeout(timeoutId);

    if (!res.ok) return null;
    const json = await res.json();
    const result = json?.chart?.result?.[0];
    if (!result) return null;
    return result;
  } catch {
    return null;
  }
}

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get('code');
  if (!code) {
    return NextResponse.json({ error: 'code required' }, { status: 400 });
  }

  try {
    // 即時走勢需涵蓋完整交易時段 09:00–13:30。daemon 的 MIS 分時序列即時無延遲，
    // 但只記錄被追蹤個股、且被檢視前的早盤靠 daemon 端 Yahoo 回補補齊。
    // 快速路徑：盤中時 daemon 若已從 09:0x 起完整 → 直接回 daemon(免等 Yahoo，維持即時)。
    const daemon = await fetchDaemonIntraday(code);
    const nowTw = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Taipei' }));
    const nowMin = nowTw.getHours() * 60 + nowTw.getMinutes();
    const marketOpen = nowTw.getDay() >= 1 && nowTw.getDay() <= 5 && nowMin >= 9 * 60 && nowMin < 13 * 60 + 35;
    const firstTickMin = daemon?.ticks?.length
      ? (() => { const t = new Date(new Date(daemon.ticks[0].time * 1000).toLocaleString('en-US', { timeZone: 'Asia/Taipei' })); return t.getHours() * 60 + t.getMinutes(); })()
      : 9999;
    if (marketOpen && daemon && firstTickMin <= 9 * 60 + 10) {
      return NextResponse.json({ code, prevClose: daemon.prevClose, ticks: daemon.ticks, source: 'mis-fast' }, { headers: NO_STORE });
    }

    // 一般路徑：以 Yahoo 全日為主幹，盤中再把 daemon 更即時的尾段接上，兼顧完整與即時。
    const [resTw, resTwo] = await Promise.all([
      fetchIntraday(`${code}.TW`),
      fetchIntraday(`${code}.TWO`),
    ]);

    const toTimeStr = (ts: number) => {
      const tw = new Date(new Date(ts * 1000).toLocaleString('en-US', { timeZone: 'Asia/Taipei' }));
      return `${String(tw.getHours()).padStart(2, '0')}:${String(tw.getMinutes()).padStart(2, '0')}`;
    };

    const result = resTw || resTwo;
    let ticks: { time: number; timeStr: string; close: number; volume: number }[] = [];
    let prevClose = 0;

    if (result) {
      const timestamps: number[] = result.timestamp ?? [];
      const quote = result.indicators?.quote?.[0] ?? {};
      const closes: (number | null)[] = quote.close ?? [];
      const volumes: (number | null)[] = quote.volume ?? [];
      ticks = timestamps.map((ts, idx) => {
        const close = closes[idx];
        if (close === null || close === undefined) return null;
        return { time: ts, timeStr: toTimeStr(ts), close, volume: volumes[idx] ?? 0 };
      }).filter((t): t is { time: number; timeStr: string; close: number; volume: number } => t !== null);
      const meta = result.meta ?? {};
      prevClose = meta.chartPreviousClose ?? meta.previousClose ?? (ticks[0]?.close ?? 0);
    }

    // 盤中：把 daemon 更即時、比 Yahoo 尾端更新的點接上(消除 20 分延遲)
    if (daemon?.ticks?.length) {
      const lastYahoo = ticks.length ? ticks[ticks.length - 1].time : 0;
      const tail = daemon.ticks.filter((t: { time: number }) => t.time > lastYahoo);
      if (ticks.length === 0) { ticks = daemon.ticks; }          // Yahoo 失敗 → 全用 daemon
      else if (tail.length) { ticks = [...ticks, ...tail]; }      // 接上即時尾段
      if (!prevClose) prevClose = daemon.prevClose;
    }

    if (ticks.length === 0) {
      return NextResponse.json({ error: 'No data found' }, { status: 404 });
    }

    return NextResponse.json({ code, prevClose, ticks, source: result ? 'yahoo+mis' : 'mis' }, { headers: NO_STORE });
  } catch (error) {
    console.error(`Stock intraday proxy error for ${code}:`, error);
    return NextResponse.json({ error: 'Failed to fetch stock intraday data' }, { status: 500 });
  }
}
