'use client';

// ── 盤中戰情「📈 即時漲跌」分頁 ──────────────────────────────────────
// 全市場(~1900檔)左右兩欄熱力方塊：左=全部上漲、右=全部下跌（不設上限）。
// 欄數可調(桌機·localStorage 記憶)、左右獨立排序(漲幅/價量/成交量/價格)、
// 點方塊展開即時K線。資料：/api/twse/market-snapshot（daemon 每分掃）。

import { useEffect, useMemo, useState } from 'react';
import StockTrendChart from '@/components/WatchlistTracker/StockTrendChart';
import AddCandidateButton from '@/components/Candidates/AddCandidateButton';
import OnlyCandidatesToggle from '@/components/Candidates/OnlyCandidatesToggle';
import { useAppStore } from '@/lib/store';

interface Snap {
  code: string; name: string; price: number; change: number; changePercent: number;
  volume: number; volX: number | null; market: string; open: number; high: number; low: number;
}
type SortKey = 'chg' | 'score' | 'value' | 'vol' | 'price';
const SORTS: { key: SortKey; label: string }[] = [
  { key: 'chg', label: '漲跌幅' },
  { key: 'score', label: '強度分' },
  { key: 'value', label: '價量(成交值)' },
  { key: 'vol', label: '成交量' },
  { key: 'price', label: '價格' },
];

// 強度評比（與急漲跌頁同制）：|漲跌幅|×5(≤50) + 量能倍數×10(≤30) + |漲跌幅|×2(≤20)
const scoreOf = (q: Snap) => Math.round(
  Math.min(50, Math.abs(q.changePercent) * 5) + Math.min(30, (q.volX ?? 1) * 10) + Math.min(20, Math.abs(q.changePercent) * 2)
);
const strengthOf = (chg: number): { t: string; c: string } => {
  const a = Math.abs(chg);
  if (a >= 9.9) return { t: chg > 0 ? '漲停' : '跌停', c: chg > 0 ? '#f03e3e' : '#2f9e44' };
  if (a >= 7) return { t: chg > 0 ? '強勢' : '急跌', c: chg > 0 ? '#f97316' : '#16a34a' };
  if (a >= 5) return { t: chg > 0 ? '中強' : '中跌', c: '#eab308' };
  return { t: '溫和', c: '#94a3b8' };
};

function isTwTradingHours(): boolean {
  const tw = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Taipei' }));
  const d = tw.getDay(); const v = tw.getHours() * 60 + tw.getMinutes();
  return d >= 1 && d <= 5 && v >= 9 * 60 && v < 13 * 60 + 35;
}

// 熱力底色：漲紅跌綠，強度隨 |漲跌幅| 遞增（台股慣例）
const tileBg = (chg: number) => {
  const a = Math.min(0.55, 0.10 + Math.abs(chg) / 10 * 0.45);
  return chg >= 0 ? `rgba(240,62,62,${a})` : `rgba(47,158,68,${a})`;
};

function Column({ title, icon, color, items, sort, setSort, cols, openCode, setOpenCode, candidateSet }: {
  title: string; icon: string; color: string; items: Snap[];
  sort: SortKey; setSort: (s: SortKey) => void; cols: number;
  openCode: string | null; setOpenCode: (c: string | null) => void;
  candidateSet: Set<string>;
}) {
  return (
    <div style={{ minWidth: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 6 }}>
        <span style={{ fontWeight: 900, fontSize: 13.5, color }}>{icon} {title}</span>
        <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)' }}>{items.length.toLocaleString()} 檔</span>
        <span style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>
          {(() => { const a = items.filter(q => Math.abs(q.changePercent) >= 9.9).length, b = items.filter(q => { const x = Math.abs(q.changePercent); return x >= 7 && x < 9.9; }).length, c2 = items.filter(q => { const x = Math.abs(q.changePercent); return x >= 5 && x < 7; }).length; return `${title === '上漲' ? '漲停' : '跌停'}${a}·${title === '上漲' ? '強勢' : '急跌'}${b}·${title === '上漲' ? '中強' : '中跌'}${c2}`; })()}
        </span>
        <span style={{ marginLeft: 'auto', display: 'inline-flex', gap: 4 }}>
          {SORTS.map(s => (
            <button key={s.key} onClick={() => setSort(s.key)}
              style={{ padding: '2px 8px', borderRadius: 10, fontSize: 10.5, fontWeight: 700, cursor: 'pointer',
                border: `1px solid ${sort === s.key ? `${color}88` : 'var(--border-primary)'}`,
                background: sort === s.key ? `${color}22` : 'transparent',
                color: sort === s.key ? 'var(--text-primary)' : 'var(--text-muted)' }}>
              {s.label}
            </button>
          ))}
        </span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 4 }}>
        {items.map(q => {
          const otc = q.market === 'otc';
          const open = openCode === q.code;
          return (
            <div key={q.code} style={{ display: 'contents' }}>
              <div onClick={() => setOpenCode(open ? null : q.code)}
                style={{ position: 'relative', cursor: 'pointer', padding: '5px 7px', borderRadius: 7,
                  background: tileBg(q.changePercent), border: open ? '1px solid #7dd3fc' : '1px solid transparent', minWidth: 0,
                  ...(candidateSet.has(q.code) ? { boxShadow: '0 0 0 1.5px rgba(245,159,0,0.8)' } : {}) }}>
                <span style={{ position: 'absolute', top: 2, right: 4, fontSize: 8.5, fontWeight: 800, color: otc ? '#fcd34d' : '#93c5fd', opacity: 0.9 }}>{otc ? '櫃' : '市'}</span>
                <span style={{ position: 'absolute', top: 2, left: 3 }}><AddCandidateButton code={q.code} variant="icon" /></span>
                <div style={{ fontSize: 11.5, fontWeight: 800, lineHeight: 1.25 }}>{q.code}</div>
                <div style={{ fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{q.name}</div>
                <div style={{ fontSize: 10.5, fontWeight: 800, fontFamily: 'JetBrains Mono, monospace', whiteSpace: 'nowrap' }}>
                  {q.price} <span>{q.changePercent >= 0 ? '+' : ''}{q.changePercent.toFixed(1)}%</span>
                </div>
                <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.75)', whiteSpace: 'nowrap', display: 'flex', gap: 4, alignItems: 'center' }}>
                  <span>{Math.round(q.volume / 1000).toLocaleString()} 張{q.volX != null ? `·${q.volX}x` : ''}</span>
                  {(() => { const st = strengthOf(q.changePercent); return <span style={{ marginLeft: 'auto', fontWeight: 800, color: st.c === '#94a3b8' ? 'rgba(255,255,255,0.6)' : '#fff', background: `${st.c}66`, borderRadius: 4, padding: '0 3px' }}>{st.t}{scoreOf(q)}</span>; })()}
                </div>
              </div>
              {open && (
                <div style={{ gridColumn: '1 / -1', padding: '4px 2px 8px' }} onClick={e => e.stopPropagation()}>
                  <StockTrendChart code={q.code} name={q.name} closePrice={q.price} livePrice={q.price} changePercent={q.changePercent} volume={q.volume} />
                </div>
              )}
            </div>
          );
        })}
      </div>
      {items.length === 0 && <div style={{ fontSize: 12.5, color: 'var(--text-muted)', padding: '10px 4px' }}>無</div>}
    </div>
  );
}

export default function RiseFallPanel() {
  const [snaps, setSnaps] = useState<Snap[]>([]);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);
  const [marketOpen, setMarketOpen] = useState(false);
  const [sortUp, setSortUp] = useState<SortKey>('chg');
  const [sortDn, setSortDn] = useState<SortKey>('chg');
  const [cols, setCols] = useState(4);
  const [openCode, setOpenCode] = useState<string | null>(null);
  const [onlyCand, setOnlyCand] = useState(false);
  const compareCodes = useAppStore(s => s.compareCodes);
  const candidateSet = useMemo(() => new Set(compareCodes), [compareCodes]);

  useEffect(() => { try { const c = parseInt(localStorage.getItem('rfCols') || '4'); if (c >= 2 && c <= 10) setCols(c); } catch { /* ignore */ } }, []);
  const saveCols = (c: number) => { setCols(c); try { localStorage.setItem('rfCols', String(c)); } catch { /* ignore */ } };

  useEffect(() => {
    let live = true;
    const load = () => fetch('/api/twse/market-snapshot').then(r => (r.ok ? r.json() : null)).then(d => {
      if (!live || !d?.quotes) return;
      setSnaps(d.quotes); setUpdatedAt(d.updatedAt ?? null); setMarketOpen(!!d.marketOpen);
    }).catch(() => {});
    load();
    const t = setInterval(load, isTwTradingHours() ? 30000 : 120000);
    return () => { live = false; clearInterval(t); };
  }, []);

  const sorter = (k: SortKey, up: boolean) => (a: Snap, b: Snap) =>
    k === 'chg' ? (up ? b.changePercent - a.changePercent : a.changePercent - b.changePercent)
      : k === 'score' ? scoreOf(b) - scoreOf(a)
      : k === 'value' ? (b.price * b.volume) - (a.price * a.volume)
      : k === 'vol' ? b.volume - a.volume
      : b.price - a.price;

  const pool = useMemo(() => onlyCand ? snaps.filter(q => candidateSet.has(q.code)) : snaps, [snaps, onlyCand, candidateSet]);
  const risers = useMemo(() => pool.filter(q => q.changePercent > 0).sort(sorter(sortUp, true)), [pool, sortUp]);
  const fallers = useMemo(() => pool.filter(q => q.changePercent < 0).sort(sorter(sortDn, false)), [pool, sortDn]);
  const flat = pool.length - risers.length - fallers.length;

  return (
    <div style={{ flex: '1 1 100%', minWidth: 320, padding: '10px 12px', borderRadius: 12, background: 'rgba(61,142,248,0.05)', border: '1px solid rgba(61,142,248,0.22)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 8 }}>
        <span style={{ fontSize: 14.5, fontWeight: 900, color: '#7dd3fc' }}>📈 即時漲跌</span>
        <span style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
          全市場 {snaps.length.toLocaleString()} 檔 · ▲{risers.length.toLocaleString()} ▼{fallers.length.toLocaleString()} 平{flat}
          {updatedAt ? ` · ${new Date(updatedAt).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })}` : ''}{!marketOpen ? ' · ⏸ 非盤中(最後快照)' : ''}
        </span>
        <OnlyCandidatesToggle on={onlyCand} setOn={setOnlyCand} />
        <span className="mobile-hide" style={{ marginLeft: 'auto', display: 'inline-flex', gap: 6, alignItems: 'center', fontSize: 11, color: 'var(--text-muted)' }}>
          欄數
          <select value={cols} onChange={e => saveCols(+e.target.value)}
            style={{ background: 'var(--bg-input)', color: 'var(--text-primary)', border: '1px solid var(--border-primary)', borderRadius: 6, fontSize: 11, padding: '2px 4px' }}>
            {[2, 3, 4, 5, 6, 8, 10].map(v => <option key={v} value={v}>{v}</option>)}
          </select>
          <span>· 點方塊看即時K線</span>
        </span>
      </div>
      {/* 左右兩欄固定 1:1 撐滿（使用者定案：漲左跌右並排，不因寬度換行變上下排） */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: 12, alignItems: 'flex-start' }}>
        <Column title="上漲" icon="▲" color="#f03e3e" items={risers} sort={sortUp} setSort={setSortUp} cols={cols} openCode={openCode} setOpenCode={setOpenCode} candidateSet={candidateSet} />
        <Column title="下跌" icon="▼" color="#2f9e44" items={fallers} sort={sortDn} setSort={setSortDn} cols={cols} openCode={openCode} setOpenCode={setOpenCode} candidateSet={candidateSet} />
      </div>
      <div style={{ marginTop: 8, fontSize: 11, color: 'var(--text-muted)' }}>
        底色深淺＝漲跌幅強度（紅漲綠跌）；左右欄各自獨立排序；每 30 秒更新。非投資建議。
      </div>
    </div>
  );
}
